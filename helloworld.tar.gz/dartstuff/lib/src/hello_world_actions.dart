import 'package:w_flux/w_flux.dart';

class HelloWorldActions {

  Action<String> updateDisplayText = new Action<String>();

}